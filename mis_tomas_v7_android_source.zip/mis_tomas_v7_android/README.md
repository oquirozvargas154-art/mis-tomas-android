# Mis Tomas v4 — preparada para Android/PWA

Cambios principales:
- Manifest más completo.
- Descripción de instalación.
- Orientación vertical.
- Capturas de pantalla PWA.
- Iconos any + maskable.
- Service worker actualizado.
- Configuración Netlify para rutas y tipos MIME.
- Lista para volver a probar en PWABuilder.

## Cómo actualizar Netlify
1. Descomprime `mis_tomas_v4_android.zip`.
2. En Netlify abre el proyecto actual.
3. Ve a Deploys.
4. Usa "Deploy manually" / "Drag and drop".
5. Sube la carpeta `mis_tomas_v4_android` completa o su contenido.
6. Espera a que el deploy quede Published.
7. Abre la misma URL del sitio y verifica que cargue.
8. Luego vuelve a PWABuilder y analiza esa misma URL.
