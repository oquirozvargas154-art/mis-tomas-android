# Mis Tomas V6 Android — alarmas nativas

Esta versión conserva la interfaz web de Mis Tomas y agrega Capacitor + Local Notifications para Android.

## Qué cambia
- Solicita permiso de notificaciones en Android 13+.
- Crea un canal de recordatorios con importancia alta.
- Programa localmente próximas tomas (hasta 60 avisos pendientes).
- Usa `allowWhileIdle` para mejorar la entrega con el teléfono bloqueado.
- Incluye permisos para alarmas exactas; Android puede pedir habilitarlas en Ajustes.
- Al tocar una notificación, abre el perfil y la toma correspondiente.

## Compilar
1. `npm install`
2. `npm run android:init`
3. Desde `android/`, generar un APK debug con Gradle o Android Studio.

Para siguientes cambios: `npm run android:sync`.

> La versión publicada en Netlify puede seguir existiendo como PWA. Las alarmas locales exactas requieren la aplicación Android compilada con Capacitor.
