# Mis Tomas V7 - diagnóstico de alarmas

Esta versión agrega un canal nuevo de Android (`medication-reminders-v7`), prueba directa a 1 minuto, comprobación de permisos, alarmas exactas y contador de notificaciones pendientes.

Prueba: crear un perfil -> Ajustes -> Activar -> Probar alarma en 1 minuto -> bloquear teléfono.
