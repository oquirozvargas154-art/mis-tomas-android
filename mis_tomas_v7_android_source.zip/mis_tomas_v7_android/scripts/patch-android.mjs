import fs from 'node:fs';
import pathMod from 'node:path';
const path='android/app/src/main/AndroidManifest.xml';
if(!fs.existsSync(path)){console.error('No existe AndroidManifest.xml. Ejecuta npx cap add android primero.');process.exit(1)}
let s=fs.readFileSync(path,'utf8');
const perms=[
  '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
  '<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />',
  '<uses-permission android:name="android.permission.USE_EXACT_ALARM" />'
];
for(const p of perms){if(!s.includes(p))s=s.replace('<application',`${p}\n    <application`)}
fs.writeFileSync(path,s);
const rawDir='android/app/src/main/res/raw';
fs.mkdirSync(rawDir,{recursive:true});
fs.copyFileSync('mis_tomas_alarm.wav',pathMod.join(rawDir,'mis_tomas_alarm.wav'));
console.log('Permisos y sonido de alarma Android aplicados.');
