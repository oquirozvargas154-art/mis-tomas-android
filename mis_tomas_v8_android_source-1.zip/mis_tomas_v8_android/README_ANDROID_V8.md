# Mis Tomas V8 Prueba

Versión de diagnóstico enfocada en alarmas con pantalla bloqueada.

- Package: cl.tottemlab.mistomas.v8test
- Canal nuevo: medication-reminders-v8
- Prueba controlada a 10 segundos
- WAKE_LOCK y RECEIVE_BOOT_COMPLETED en AndroidManifest
- Mantiene alarmas exactas y allowWhileIdle
- Ajuste superior con safe-area para evitar solapamiento con la barra de estado
