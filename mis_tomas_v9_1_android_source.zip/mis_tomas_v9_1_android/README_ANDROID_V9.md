# Mis Tomas V9.1 – prueba de alarma nativa

V9.1 cambia la prueba de alarma: usa Android AlarmManager.setAlarmClock() y un BroadcastReceiver nativo, en lugar de depender de Capacitor Local Notifications para disparar la prueba.

## Prueba
1. Instalar V9.1.
2. Permitir notificaciones y “Alarmas y recordatorios”.
3. Ajustes > Probar alarma en 10 segundos.
4. Bloquear la pantalla inmediatamente.
5. Confirmar si sonido/vibración aparecen sin encender manualmente la pantalla.

El sonido de prueba dura aproximadamente 10 segundos. La repetición cada 5 minutos se añadirá después de validar esta prueba con pantalla apagada.
