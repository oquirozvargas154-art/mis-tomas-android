import fs from 'node:fs';
import pathMod from 'node:path';
const manifest='android/app/src/main/AndroidManifest.xml';
if(!fs.existsSync(manifest)){console.error('No existe AndroidManifest.xml. Ejecuta npx cap add android primero.');process.exit(1)}
let s=fs.readFileSync(manifest,'utf8');
// V9: SCHEDULE_EXACT_ALARM is user-granted. Do not declare USE_EXACT_ALARM at the same time.
s=s.replace(/\s*<uses-permission android:name="android.permission.USE_EXACT_ALARM" \/>/g,'');
const perms=[
 '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
 '<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />',
 '<uses-permission android:name="android.permission.WAKE_LOCK" />',
 '<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />',
 '<uses-permission android:name="android.permission.VIBRATE" />'
];
for(const p of perms){if(!s.includes(p))s=s.replace('<application',`${p}\n    <application`)}
const receiver='        <receiver android:name=".MedicationAlarmReceiver" android:exported="false" />';
if(!s.includes('MedicationAlarmReceiver'))s=s.replace('</application>',`${receiver}\n    </application>`);
fs.writeFileSync(manifest,s);
const rawDir='android/app/src/main/res/raw'; fs.mkdirSync(rawDir,{recursive:true});
fs.copyFileSync('mis_tomas_alarm.wav',pathMod.join(rawDir,'mis_tomas_alarm.wav'));
const pkg='cl.tottemlab.mistomas.v9test';
const javaDir='android/app/src/main/java/'+pkg.replaceAll('.','/'); fs.mkdirSync(javaDir,{recursive:true});
fs.writeFileSync(pathMod.join(javaDir,'MainActivity.java'),`package ${pkg};
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;
public class MainActivity extends BridgeActivity {
 @Override public void onCreate(Bundle savedInstanceState) {
   registerPlugin(MedicationAlarmPlugin.class);
   super.onCreate(savedInstanceState);
 }
}\n`);
fs.writeFileSync(pathMod.join(javaDir,'MedicationAlarmPlugin.java'),`package ${pkg};
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
@CapacitorPlugin(name = "MedicationAlarm")
public class MedicationAlarmPlugin extends Plugin {
 @PluginMethod public void testAlarm(PluginCall call) {
   int seconds=call.getInt("seconds",10); String title=call.getString("title","Hora de tu medicamento"); String body=call.getString("body","Abre Mis Tomas para confirmar la toma");
   AlarmManager am=(AlarmManager)getContext().getSystemService(Context.ALARM_SERVICE);
   if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.S && !am.canScheduleExactAlarms()){call.reject("EXACT_ALARM_PERMISSION");return;}
   long when=System.currentTimeMillis()+Math.max(3,seconds)*1000L;
   Intent i=new Intent(getContext(),MedicationAlarmReceiver.class); i.putExtra("title",title); i.putExtra("body",body); i.putExtra("id",209000001);
   PendingIntent fire=PendingIntent.getBroadcast(getContext(),209000001,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
   Intent show=new Intent(getContext(),MainActivity.class); PendingIntent showPi=PendingIntent.getActivity(getContext(),209000002,show,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
   am.setAlarmClock(new AlarmManager.AlarmClockInfo(when,showPi),fire);
   JSObject r=new JSObject(); r.put("scheduled",true); r.put("seconds",seconds); r.put("triggerAt",when); call.resolve(r);
 }
}\n`);
fs.writeFileSync(pathMod.join(javaDir,'MedicationAlarmReceiver.java'),`package ${pkg};
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
public class MedicationAlarmReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c, Intent intent) {
   String channel="medication-alarm-v9-native";
   Uri sound=Uri.parse("android.resource://"+c.getPackageName()+"/"+R.raw.mis_tomas_alarm);
   NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
   if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(channel,"Alarmas de medicamentos",NotificationManager.IMPORTANCE_HIGH); ch.setDescription("Alarmas importantes de Mis Tomas"); ch.enableVibration(true); ch.setVibrationPattern(new long[]{0,500,250,500,250,500}); ch.setSound(sound,new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()); nm.createNotificationChannel(ch);}
   Intent open=new Intent(c,MainActivity.class); open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
   PendingIntent pi=PendingIntent.getActivity(c,209000003,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
   NotificationCompat.Builder b=new NotificationCompat.Builder(c,channel).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(intent.getStringExtra("title")).setContentText(intent.getStringExtra("body")).setPriority(NotificationCompat.PRIORITY_MAX).setCategory(NotificationCompat.CATEGORY_ALARM).setSound(sound).setVibrate(new long[]{0,500,250,500,250,500}).setContentIntent(pi).setAutoCancel(false).setOngoing(false);
   try{NotificationManagerCompat.from(c).notify(intent.getIntExtra("id",209000001),b.build());}catch(SecurityException ignored){}
 }
}\n`);
console.log('V9: alarma nativa AlarmClock + receptor + sonido de 10 s aplicados.');
